import {
  Long,
  TelegramClient,
  type StarGift,
  type StarGiftUnique,
  type InputPeerLike,
} from "@mtcute/bun";
import pLimit from "p-limit";
import retry from "async-retry";

const API_ID = 1;
const API_HASH = "a";

const MAX_CONCURRENT_TASKS = 7; // Max parallel API calls per interval
const PURCHASE_DELAY_MS = 1000; // Delay between buy calls
const POLL_INTERVAL_MS = 1400; // Interval between full polling rounds
const READERS_COUNT = 1; // Number of reader sessions

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

interface ResalableGift {
  id: string;
  title: string;
  floor: number;
}

async function main(): Promise<void> {
  const buyerClient = new TelegramClient({
    apiId: API_ID,
    apiHash: API_HASH,
    storage: "buyer.session",
  });
  const readerClients = Array.from(
    { length: READERS_COUNT },
    (_, i) =>
      new TelegramClient({
        apiId: API_ID,
        apiHash: API_HASH,
        storage: `reader${i + 1}.session`,
      })
  );

  const meBuyer = await buyerClient.start({
    phone: () => buyerClient.input("Buyer Phone > "),
    code: () => buyerClient.input("Code > "),
    password: () => buyerClient.input("Password > "),
  });
  console.log(`Buyer logged in as ${meBuyer.displayName}`);

  await Promise.all(
    readerClients.map(async (rc, i) => {
      const me = await rc.start({
        phone: () => rc.input(`Reader${i + 1} Phone > `),
        code: () => rc.input("Code > "),
        password: () => rc.input("Password > "),
      });
      console.log(`Reader${i + 1} logged in as ${me.displayName}`);
    })
  );

  const gifts = await getResalableGifts(readerClients[0] as TelegramClient);
  console.log(`Found ${gifts.length} resalable gifts.`);

  const limit = pLimit(MAX_CONCURRENT_TASKS);

  async function pollOnce(): Promise<void> {
    gifts.forEach((gift, idx) => {
      const reader = readerClients[idx % READERS_COUNT] as TelegramClient;
      limit(() =>
        retry(
          async () => {
            await processResalePage(reader, buyerClient, gift);
          },
          {
            retries: 3,
            factor: 2,
            minTimeout: 500,
            onRetry(err, attempt) {
              console.warn(
                `Retry #${attempt} for ${gift.title}:`,
                (err as Error).message
              );
            },
          }
        )
      ).catch((err) => {
        console.error(`Task failed for ${gift.title}:`, err.message);
      });
    });
  }
  await pollOnce();
  setInterval(pollOnce, POLL_INTERVAL_MS);
}

async function getResalableGifts(
  rtg: TelegramClient
): Promise<ResalableGift[]> {
  const stock: StarGift[] = await rtg.getStarGiftOptions();
  return stock
    .filter(
      (g) =>
        g.isSoldOut &&
        g.isLimited &&
        !!g.title &&
        !!g.resaleFloorPrice &&
        !g.title.includes("Desk Calendar")
    )
    .map((g) => ({
      id: Long.fromValue(g.id).toString(),
      title: g.title as string,
      floor: Number(g.resaleFloorPrice!.toString()),
    }));
}

async function processResalePage(
  rtg: TelegramClient,
  btg: TelegramClient,
  gift: ResalableGift
): Promise<void> {
  const page: StarGiftUnique[] = await rtg.getResaleOptions({
    giftId: Long.fromValue(gift.id),
    sort: "price",
    limit: 1,
  });

  for (const item of page) {
    const price = Number(item.resellPrice?.toString() ?? 0);
    const isCheap = price < Math.max(180, Math.floor(gift.floor * 0.35));

    console.log(
      `🔎 Checking ${item.slug} at ${price} Stars, cheap: ${isCheap}`
    );

    if (!isCheap) continue;

    try {
      await btg.buyResaleGift({
        slug: item.slug,
        recipient: "self" as InputPeerLike,
      });
      console.log(`✅ Purchased ${item.slug} at ${price} Stars`);

      await delay(PURCHASE_DELAY_MS);
    } catch (buyErr: any) {
      console.warn(
        `❌ Failed to buy ${item.slug} that costs ${price} Stars.`,
        buyErr.message
      );
    }
  }
}

main().catch((err) => console.error("Fatal:", err));
